require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6287712933029"
global.namaowner = "Xluzy Hosting"
global.namaowner2 = "Xluzy Hosting"

//======== Setting Bot & Link ========//
global.namabot = "Eula Bot WhatsApp " 
global.namabot2 = "Eula Bot WhatsApp"
global.version = "Pushkontak"
global.foother = "Created By Xluzy"
global.waowner = "https://wa.me/6287712933029"
global.linkgc = 'https://chat.whatsapp.com/D6EMJU8sRhU0RK7avhF1RF'
global.saluran = "https://whatsapp.com/channel/0029VasbVbq4Y9lsBresns2t"
global.thumb = fs.readFileSync("./media/thumb.jpg")

//========== Setting Event ==========//
global.autoread = false
global.anticall = false
global.autoreadsw = false
global.owneroff = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 8500
global.delayjpm = 8000

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi "Belum Tersedia"
global.dana = "Belum Tersedia"
global.gopay = "Belum Tersedia"
global.ovo = "Belum Tersedia"
global.linkqris = "https://img.hotimg.com/1000015377.jpeg"
global.qris = fs.readFileSync("./media/qris.jpg")
                             
//========= Setting Message =========//
global.msg = {
"error": "*[ 👾 ]* Error terjadi kesalahan",
"done": "*[ ✅ ]* Proses Selesai", 
"wait": "*[ ⌛ ]* Memproses Permintaan", 
"group": "*[ 👥 ]* Command Ini Hanya Untuk Didalam Grup", 
"private": "*[ 🔐 ]* Command Ini Hanya Untuk Di Private Chat", 
"admin": "*[ 👤 ]* Command Ini Hanya Untuk Admin Grup", 
"adminbot": "*[ 🤖 ]* Command Ini Dapat Di Gunakan Ketika Bot Menjadi Admin", 
"owner": "*[ 👤 ]* Maaf Command Ini Hanya Untuk Owner"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})